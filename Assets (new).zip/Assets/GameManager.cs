﻿using UnityEngine;
using UnityEngine.SceneManagement;
using TMPro;
using System.Collections;

public class GameManager : MonoBehaviour
{
    public static GameManager instance;

    // ---------------- GAME SETTINGS ----------------
    [Header("Game Settings")]
    public int gameTime = 60;
    public bool isMultiplayer = false;

    private float currentTime;

    // 🔥 FIX: tambahkan ini (hilang di script kamu sebelumnya)
    private bool goldenGoalActive = false;

    // ---------------- SCORE ----------------
    public int leftScore = 0;
    public int rightScore = 0;
    public TMP_Text leftScoreText;
    public TMP_Text rightScoreText;
    public TMP_Text timerText;

    // ---------------- BALL ----------------
    public Transform ball;
    public Vector2 ballStartPos = Vector2.zero;
    public float startDelay = 1f;
    public BallControl ballControl;

    private Coroutine timerCoroutine;


    private void Awake()
    {
        if (instance == null)
        {
            instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else
        {
            Destroy(gameObject);
        }
    }


    private void Start()
    {
        // Apply selected time from GameSettings
        gameTime = GameSettings.gameTime;
        isMultiplayer = GameSettings.isMultiplayer;

        currentTime = gameTime;

        UpdateScoreUI();

        if (ballControl == null && ball != null)
            ballControl = ball.GetComponent<BallControl>();

        timerCoroutine = StartCoroutine(GameTimer());
    }

    // ------------------- TIMER -------------------
    IEnumerator GameTimer()
    {
        while (currentTime > 0)
        {
            yield return new WaitForSeconds(1f);

            currentTime--;

            if (timerText != null)
                timerText.text = FormatTime(currentTime);
        }

        EndGame();
    }

    // ------------------- SCORE -------------------
    public void ScoreLeft()
    {
        int multiplier = ballControl.GetDoubleMultiplierForPlayer(1);
        leftScore += multiplier;

        UpdateScoreUI();
        ResetAfterGoal();
    }

    public void ScoreRight()
    {
        int multiplier = ballControl.GetDoubleMultiplierForPlayer(2);
        rightScore += multiplier;

        UpdateScoreUI();
        ResetAfterGoal();
    }

    // ------------------- GOAL -------------------
    public void HandleGoal(bool isLeftGoal)
    {
        if (isLeftGoal) ScoreRight();
        else ScoreLeft();
    }

    void UpdateScoreUI()
    {
        if (leftScoreText != null)
            leftScoreText.text = leftScore.ToString();

        if (rightScoreText != null)
            rightScoreText.text = rightScore.ToString();
    }

    // ------------------- BALL & POWERUPS -------------------
    void ResetAfterGoal()
    {
        if (ballControl != null)
            ballControl.ResetPowerUps();

        RemoveAllPowerupsOnField();

        StartCoroutine(ResetBallWithDelay());
    }

    void RemoveAllPowerupsOnField()
    {
        GameObject[] powerups = GameObject.FindGameObjectsWithTag("Powerup");
        foreach (GameObject p in powerups)
            Destroy(p);
    }

    IEnumerator ResetBallWithDelay()
    {
        if (ball == null) yield break;

        Rigidbody2D rb = ball.GetComponent<Rigidbody2D>();
        if (rb == null) yield break;

        rb.linearVelocity = Vector2.zero;
        ball.position = ballStartPos;

        yield return new WaitForSeconds(startDelay);

        float dir = Random.value > 0.5f ? 1 : -1;
        rb.AddForce(new Vector2(250 * dir, Random.Range(-200, 200)));
    }

    // ------------------- END GAME -------------------
    void EndGame()
    {
        if (leftScore > rightScore)
            SceneManager.LoadScene("YouWinScene");
        else
            SceneManager.LoadScene("YouLoseScene");

        leftScore = 0;
        rightScore = 0;
        currentTime = gameTime;
    }

    // ------------------- UTILITY -------------------
    string FormatTime(float time)
    {
        int minutes = Mathf.FloorToInt(time / 60);
        int seconds = Mathf.FloorToInt(time % 60);
        return minutes.ToString("00") + ":" + seconds.ToString("00");
    }

    public void SetGameSettings(int timeInSeconds, bool multiplayer)
    {
        gameTime = timeInSeconds;
        isMultiplayer = multiplayer;

        currentTime = gameTime;

        Debug.Log("GameSettings applied: " + timeInSeconds + " secs | Multiplayer = " + multiplayer);
    }

    // ------------------- RESTART FIX -------------------
    public void ResetForRestart()
    {
        leftScore = 0;
        rightScore = 0;

        currentTime = gameTime;
        goldenGoalActive = false;

        StopAllCoroutines();
        timerCoroutine = StartCoroutine(GameTimer());  // FIX TIMER NOT STARTING AGAIN
    }

    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            Application.Quit();
        }
    }
}
