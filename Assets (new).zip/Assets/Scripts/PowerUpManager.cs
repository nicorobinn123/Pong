using System.Collections;
using UnityEngine;

public class PowerUpManager : MonoBehaviour
{
    [Header("Prefabs (assign in Inspector)")]
    public GameObject[] powerUpPrefabs; // 3 prefabs: DoubleScore, SpeedUp, ReverseDirection

    [Header("Spawn timing (seconds)")]
    public float minSpawnTime = 3f;
    public float maxSpawnTime = 7f;

    [Header("Spawn area (world coords)")]
    public Vector2 minPos = new Vector2(-6f, -3f);
    public Vector2 maxPos = new Vector2(6f, 3f);

    [Header("Options")]
    public int maxActivePowerups = 1; // spawn paling banyak N di lapangan

    // internal
    private int activeCount = 0;
    private bool spawning = true;

    void Start()
    {
        // safety check
        if (powerUpPrefabs == null || powerUpPrefabs.Length == 0)
        {
            Debug.LogError("PowerUpManager: powerUpPrefabs not assigned. Please assign in Inspector.");
            enabled = false;
            return;
        }

        StartCoroutine(SpawnLoop());
    }

    IEnumerator SpawnLoop()
    {
        while (spawning)
        {
            // tunggu random time
            float wait = Random.Range(minSpawnTime, maxSpawnTime);
            yield return new WaitForSeconds(wait);

            // hanya spawn jika belum melebihi limit aktif
            if (activeCount >= maxActivePowerups)
                continue;

            SpawnRandomPowerUp();
        }
    }

    void SpawnRandomPowerUp()
    {
        // pilih prefab random
        GameObject prefab = powerUpPrefabs[Random.Range(0, powerUpPrefabs.Length)];
        Vector2 pos = GetRandomSpawnPosition();

        GameObject go = Instantiate(prefab, pos, Quaternion.identity);
        // Optional: parent to manager for hierarchy cleanliness
        go.transform.SetParent(this.transform);

        // jika want to detect when removed, attach a small helper script (PowerUp handles self-destroy on pickup)
        activeCount++;

        // hook untuk decrement ketika powerup di-destroy
        PowerUp pu = go.GetComponent<PowerUp>();
        if (pu != null)
        {
            StartCoroutine(WatchForDestroy(go));
        }
        else
        {
            // fallback: decrement after some TTL to avoid leak
            StartCoroutine(TemporaryLifetime(go, 20f));
        }
    }

    Vector2 GetRandomSpawnPosition()
    {
        float x = Random.Range(minPos.x, maxPos.x);
        float y = Random.Range(minPos.y, maxPos.y);
        return new Vector2(x, y);
    }

    IEnumerator WatchForDestroy(GameObject go)
    {
        // wait until object becomes null (destroyed)
        while (go != null)
            yield return null;

        activeCount = Mathf.Max(0, activeCount - 1);
    }

    IEnumerator TemporaryLifetime(GameObject go, float seconds)
    {
        yield return new WaitForSeconds(seconds);
        if (go != null) Destroy(go);
        activeCount = Mathf.Max(0, activeCount - 1);
    }

    // optional public stop
    public void StopSpawning() => spawning = false;
}
