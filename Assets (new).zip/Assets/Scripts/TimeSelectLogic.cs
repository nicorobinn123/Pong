using UnityEngine;
using UnityEngine.SceneManagement;

public class TimeSelectLogic : MonoBehaviour
{
    public void OnSelect1Min()
    {
        GameSettings.gameTime = 60;
        SceneManager.LoadScene("HowToPlay");
    }

    public void OnSelect3Min()
    {
        GameSettings.gameTime = 180;
        SceneManager.LoadScene("HowToPlay");
    }

    public void OnSelect5Min()
    {
        GameSettings.gameTime = 300;
        SceneManager.LoadScene("HowToPlay");
    }
}
