﻿using UnityEngine;

public class PaddleController : MonoBehaviour
{
    public enum PaddleMode { PlayerLeft, PlayerRight, AI }
    public PaddleMode mode;

    public float speed = 6f;
    public Transform ball;
    private Rigidbody2D rb;

    private void Start()
    {
        rb = GetComponent<Rigidbody2D>();

        if (GameManager.instance != null)
        {
            bool multi = GameManager.instance.isMultiplayer;

            // Player Kiri = WASD (selalu player)
            if (mode == PaddleMode.PlayerLeft)
            {
                mode = PaddleMode.PlayerLeft;
            }

            // Player Kanan → Multiplayer = PlayerRight (Arrow), Single = AI
            else if (mode == PaddleMode.PlayerRight)
            {
                if (multi)
                    mode = PaddleMode.PlayerRight;
                else
                    mode = PaddleMode.AI;
            }
        }
    }

    private void Update()
    {
        switch (mode)
        {
            case PaddleMode.PlayerLeft:
                MoveWASD();
                break;

            case PaddleMode.PlayerRight:
                MoveArrow();
                break;

            case PaddleMode.AI:
                FollowBall();
                break;
        }
    }

    void MoveWASD()
    {
        float move = 0f;
        if (Input.GetKey(KeyCode.W)) move = 1f;
        if (Input.GetKey(KeyCode.S)) move = -1f;

        rb.linearVelocity = new Vector2(0, move * speed);
    }

    void MoveArrow()
    {
        float move = 0f;
        if (Input.GetKey(KeyCode.UpArrow)) move = 1f;
        if (Input.GetKey(KeyCode.DownArrow)) move = -1f;

        rb.linearVelocity = new Vector2(0, move * speed);
    }

    void FollowBall()
    {
        if (ball == null) return;

        float target = ball.position.y - transform.position.y;
        float aiMove = Mathf.Clamp(target * 2f, -1f, 1f);

        rb.linearVelocity = new Vector2(0, aiMove * speed);
    }
}
