using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PaddleCollision : MonoBehaviour
{
    public Animator anim;

    private void Start()
    {
        if (anim == null)
            anim = GetComponent<Animator>();
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.collider.CompareTag("Ball") || collision.collider.CompareTag("Wall"))
        {
            anim.SetBool("isColliding", true);
        }
    }

    private void OnCollisionExit2D(Collision2D collision)
    {
        if (collision.collider.CompareTag("Ball") || collision.collider.CompareTag("Wall"))
        {
            anim.SetBool("isColliding", false);
        }
    }

}

