﻿using UnityEngine;

public class GameplayController : MonoBehaviour
{
    [Header("Paddles")]
    public Rigidbody2D leftPaddleRb;
    public Rigidbody2D rightPaddleRb;

    [Header("Ball")]
    public Transform ball;

    [Header("Movement Settings")]
    public float moveSpeed = 20f;
    public float aiSpeed = 12f;
    public float minY = -4.5f;
    public float maxY = 4.5f;

    private void FixedUpdate()
    {
        if (GameManager.instance == null) return;

        bool multi = GameManager.instance.isMultiplayer;

        // ------------------------
        // LEFT PADDLE
        // ------------------------
        if (leftPaddleRb != null)
        {
            float input = 0f;

            if (multi)
            {
                // MULTIPLAYER → Left pakai WASD
                if (Input.GetKey(KeyCode.W)) input = 1f;
                if (Input.GetKey(KeyCode.S)) input = -1f;
            }
            else
            {
                // SINGLE PLAYER → Player pakai Arrow Keys
                if (Input.GetKey(KeyCode.UpArrow)) input = 1f;
                if (Input.GetKey(KeyCode.DownArrow)) input = -1f;
            }

            float newY = Mathf.Clamp(leftPaddleRb.position.y + input * moveSpeed * Time.fixedDeltaTime, minY, maxY);
            leftPaddleRb.MovePosition(new Vector2(leftPaddleRb.position.x, newY));
        }

        // ------------------------
        // RIGHT PADDLE
        // ------------------------
        if (rightPaddleRb != null)
        {
            if (multi)
            {
                // MULTIPLAYER → Right pakai Arrow Keys
                float input = 0f;
                if (Input.GetKey(KeyCode.UpArrow)) input = 1f;
                if (Input.GetKey(KeyCode.DownArrow)) input = -1f;

                float newY = Mathf.Clamp(rightPaddleRb.position.y + input * moveSpeed * Time.fixedDeltaTime, minY, maxY);
                rightPaddleRb.MovePosition(new Vector2(rightPaddleRb.position.x, newY));
            }
            else
            {
                // SINGLE PLAYER → Right = AI
                if (ball != null)
                {
                    float step = aiSpeed * Time.fixedDeltaTime;
                    float targetY = Mathf.Clamp(Mathf.MoveTowards(rightPaddleRb.position.y, ball.position.y, step), minY, maxY);
                    rightPaddleRb.MovePosition(new Vector2(rightPaddleRb.position.x, targetY));
                }
            }
        }
    }
}
