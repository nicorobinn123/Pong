public static class GameSettings
{
    public static bool isMultiplayer = false;
    public static int gameTime = 60; // default 1 menit
}
