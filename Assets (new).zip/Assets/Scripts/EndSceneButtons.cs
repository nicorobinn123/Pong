﻿using UnityEngine;
using UnityEngine.SceneManagement;
using System.Collections; // ← WAJIB kalau pakai IEnumerator

public class EndSceneButtons : MonoBehaviour
{
    public void OnRestartClicked()
    {
        // langsung restart
        SceneManager.LoadScene("GamePlay");
    }

    public void OnMainMenuClicked()
    {
        SceneManager.LoadScene("MainMenu");
    }

    // contoh kalau kamu mau pakai delay
    IEnumerator RestartAfterDelay()
    {
        yield return new WaitForSeconds(1f);
        SceneManager.LoadScene("GamePlay");
    }
}
