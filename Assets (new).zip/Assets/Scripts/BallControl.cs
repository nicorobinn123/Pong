using System.Collections;
using UnityEngine;

public class BallControl : MonoBehaviour
{
    [Header("Speed")]
    public float baseSpeed = 8f;
    public float speedBoost = 0f;

    private Rigidbody2D rb;

    // DOUBLE SCORE
    public bool doubleScoreActive = false;
    public int doubleScoreOwner = 0; // 1 = left, 2 = right
    private Coroutine doubleCoroutine;

    // last hitter
    public int lastHitBy = 0;   // ALWAYS 1 or 2 after paddle hit

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        LaunchBall();
    }

    void LaunchBall()
    {
        float x = Random.value < 0.5f ? -1 : 1;
        float y = Random.Range(-1f, 1f);

        rb.linearVelocity = new Vector2(x, y).normalized * (baseSpeed + speedBoost);
    }

    private void FixedUpdate()
    {
        if (rb.linearVelocity.sqrMagnitude > 0.01f)
            rb.linearVelocity = rb.linearVelocity.normalized * (baseSpeed + speedBoost);
    }

    private void OnCollisionEnter2D(Collision2D col)
    {
        if (col.collider.CompareTag("Paddle"))
        {
            // FIXED : guaranteed EXACT names
            if (col.collider.name == "LeftPaddle") lastHitBy = 1;
            else if (col.collider.name == "RightPaddle") lastHitBy = 2;

            float y = HitFactor(transform.position,
                                col.transform.position,
                                col.collider.bounds.size.y);

            float x = (col.collider.name == "LeftPaddle") ? 1 : -1;
            rb.linearVelocity = new Vector2(x, y).normalized * (baseSpeed + speedBoost);
        }
    }

    private void OnTriggerEnter2D(Collider2D col)
    {
        if (!col.CompareTag("Powerup")) return;

        PowerUp p = col.GetComponent<PowerUp>();
        if (p == null) { Destroy(col.gameObject); return; }

        switch (p.type)
        {
            case PowerUp.PowerType.DoubleScore:
                // FIX: Even if player has not hit paddle YET, assign temporary owner
                if (lastHitBy == 0)
                {
                    // if ball goes right → assume right paddle last hit
                    lastHitBy = (rb.linearVelocity.x > 0) ? 1 : 2;
                }

                ActivateDoubleScore(lastHitBy, p.duration);
                break;

            case PowerUp.PowerType.SpeedUp:
                speedBoost += p.speedBoostAmount;
                StartCoroutine(RemoveSpeedAfter(p.speedBoostAmount, p.duration));
                break;

            case PowerUp.PowerType.ReverseDirection:
                rb.linearVelocity = -rb.linearVelocity;
                break;
        }

        Destroy(col.gameObject);
    }

    void ActivateDoubleScore(int owner, float duration)
    {
        doubleScoreActive = true;
        doubleScoreOwner = owner;

        if (doubleCoroutine != null)
            StopCoroutine(doubleCoroutine);

        doubleCoroutine = StartCoroutine(DisableDoubleScoreAfter(duration));
    }

    IEnumerator DisableDoubleScoreAfter(float sec)
    {
        yield return new WaitForSeconds(sec);
        doubleScoreActive = false;
        doubleScoreOwner = 0;
    }

    IEnumerator RemoveSpeedAfter(float amount, float sec)
    {
        yield return new WaitForSeconds(sec);
        speedBoost -= amount;
        if (speedBoost < 0) speedBoost = 0;
    }

    public int GetDoubleMultiplierForPlayer(int playerId)
    {
        if (doubleScoreActive && doubleScoreOwner == playerId)
            return 2; // ALWAYS 2×, no stacking
        return 1;
    }

    public void ResetPowerUps()
    {
        doubleScoreActive = false;
        doubleScoreOwner = 0;
        speedBoost = 0;

        if (doubleCoroutine != null)
            StopCoroutine(doubleCoroutine);
    }

    float HitFactor(Vector2 ball, Vector2 paddle, float paddleHeight)
    {
        return (ball.y - paddle.y) / paddleHeight;
    }
}
