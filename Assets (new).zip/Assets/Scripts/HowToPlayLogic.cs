using UnityEngine;
using UnityEngine.SceneManagement;

public class HowToPlayLogic : MonoBehaviour
{
    public void OnPlayButtonClicked()
    {
        SceneManager.LoadScene("Gameplay");
    }
}
