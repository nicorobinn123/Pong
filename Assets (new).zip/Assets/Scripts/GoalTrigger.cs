using UnityEngine;

public class GoalTrigger : MonoBehaviour
{
    public bool isLeftGoal = true; // Set true untuk gawang kiri, false kanan

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Ball"))
        {
            if (GameManager.instance != null)
                GameManager.instance.HandleGoal(isLeftGoal);
        }
    }
}
