using UnityEngine;
using UnityEngine.SceneManagement;

public class MainMenuLogic : MonoBehaviour
{
    public void OnSinglePlayerClicked()
    {
        GameSettings.isMultiplayer = false;

        // FIX: sync ke GameManager
        if (GameManager.instance != null)
            GameManager.instance.SetGameSettings(GameSettings.gameTime, false);

        SceneManager.LoadScene("TimeSelect");
    }

    public void OnMultiPlayerClicked()
    {
        GameSettings.isMultiplayer = true;

        // FIX: sync ke GameManager
        if (GameManager.instance != null)
            GameManager.instance.SetGameSettings(GameSettings.gameTime, true);

        SceneManager.LoadScene("TimeSelect");
    }
}
