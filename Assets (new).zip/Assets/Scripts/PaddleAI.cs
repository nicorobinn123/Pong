using UnityEngine;

public class PaddleAI : MonoBehaviour
{
    [Header("References")]
    public Transform ball;                // taruh bola ke sini lewat Inspector

    [Header("AI Settings")]
    public float speed = 1.5f;            // gerak AI lebih lambat dari player
    public float reactionDelay = 0.25f;   // AI telat membaca posisi bola
    public float inaccuracy = 0.6f;       // AI sering salah prediksi
    public float limitY = 3.5f;           // batas gerak vertical

    private float targetY;                // posisi target yang ingin dituju AI
    private float timer = 0f;

    void Update()
    {
        if (ball == null) return;

        // Menunggu sampai reaction delay tercapai sebelum update target Y
        timer += Time.deltaTime;
        if (timer >= reactionDelay)
        {
            timer = 0;

            // Ambil posisi Y bola namun ditambah inaccuracy random
            targetY = ball.position.y + Random.Range(-inaccuracy, inaccuracy);
        }

        // Gerakkan paddle menuju targetY
        Vector3 pos = transform.position;

        if (pos.y < targetY - 0.1f)
            pos.y += speed * Time.deltaTime;
        else if (pos.y > targetY + 0.1f)
            pos.y -= speed * Time.deltaTime;

        // Clamp supaya tidak keluar arena
        pos.y = Mathf.Clamp(pos.y, -limitY, limitY);

        transform.position = pos;
    }
}
