using UnityEngine;

public class PowerUp : MonoBehaviour
{
    public enum PowerType { DoubleScore, SpeedUp, ReverseDirection }
    public PowerType type;

    // Untuk SpeedUp
    public float speedBoostAmount = 4f;

    // Durasi power-up untuk double score (bola yang pakai)
    public float duration = 5f;
}
