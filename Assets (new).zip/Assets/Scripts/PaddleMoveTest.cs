using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PaddleMoveTest : MonoBehaviour
{
    public float speed = 6f;
    public bool useWASD = false;   // true = pakai WASD, false = pakai Arrow

    private Rigidbody2D rb;

    private void Start()
    {
        rb = GetComponent<Rigidbody2D>();
    }

    private void Update()
    {
        float move = 0f;

        if (useWASD)
        {
            // W = atas, S = bawah
            if (Input.GetKey(KeyCode.W)) move = 1f;
            if (Input.GetKey(KeyCode.S)) move = -1f;
        }
        else
        {
            // Arrow Up = atas, Arrow Down = bawah
            if (Input.GetKey(KeyCode.UpArrow)) move = 1f;
            if (Input.GetKey(KeyCode.DownArrow)) move = -1f;
        }

        rb.MovePosition(rb.position + new Vector2(0, move * speed * Time.deltaTime));
    }
}
