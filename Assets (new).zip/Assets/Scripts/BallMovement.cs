using UnityEngine;

public class BallController : MonoBehaviour
{
    public float startSpeed = 8f;
    public float speedIncrease = 0.5f;
    public Rigidbody2D rb;

    void Start()
    {
        LaunchBall();
    }

    void LaunchBall()
    {
        // Arah random (kiri atau kanan)
        float x = Random.value < 0.5f ? -1f : 1f;
        float y = Random.Range(-0.6f, 0.6f);

        Vector2 dir = new Vector2(x, y).normalized;
        rb.linearVelocity = dir * startSpeed;
    }

    void OnCollisionEnter2D(Collision2D collision)
    {
        // Beda reaksi ketika kena paddle atau dinding
        if (collision.collider.CompareTag("Paddle"))
        {
            BounceFromPaddle(collision);
        }
        else if (collision.collider.CompareTag("Wall"))
        {
            BounceFromWall();
        }
    }

    void BounceFromWall()
    {
        // Mantul vertikal
        rb.linearVelocity = new Vector2(rb.linearVelocity.x, -rb.linearVelocity.y);
    }

    void BounceFromPaddle(Collision2D collision)
    {
        // Posisi benturan relatif terhadap paddle
        float hitFactor = (transform.position.y - collision.transform.position.y) /
                          collision.collider.bounds.size.y;

        // Tentukan arah kiri/kanan
        float dirX = collision.transform.position.x < 0 ? 1 : -1;

        // HitFactor memberi kontrol arah (lebih tinggi / rendah = sudut lebih miring)
        Vector2 newDir = new Vector2(dirX, hitFactor).normalized;

        // Tambah kecepatan sedikit biar makin seru
        rb.linearVelocity = newDir * (rb.linearVelocity.magnitude + speedIncrease);
    }
}
